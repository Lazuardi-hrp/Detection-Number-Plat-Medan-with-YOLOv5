# Detect vehicle number plate > 2023-12-13 2:22am
https://universe.roboflow.com/universitas-negeri-medan/detect-vehicle-number-plate

Provided by a Roboflow user
License: Public Domain

